using Microsoft.VisualStudio.TestTools.UnitTesting;
using Battleships;
using System.Collections.Generic;

namespace BattleshipsTest
{
    [TestClass]
    public class BattleshipsUnitTests
    {
        [TestMethod]
        public void Test_For_Duplicate_Ship_True()
        {

            // Horizontally positioned coordinates
            List<Coordinates> coordinates = new() { new Coordinates { X = 3, Y = 7 }, new Coordinates { X = 4, Y = 7 }, new Coordinates { X = 5, Y = 7 }, new Coordinates { X = 6, Y = 8 }, new Coordinates { X = 7, Y = 7 } };


            // Vertically orientated ship coordinates below deliberately intersects with horizontally positioned coordinates (4,7) above
            Ship ship = new() { CoOrds = new() { new Coordinates { X = 4, Y = 3 }, new Coordinates { X = 4, Y = 4 }, new Coordinates { X = 4, Y = 5 }, new Coordinates { X = 4, Y = 6 }, new Coordinates { X = 4, Y = 7 } } };
            Player player = new() { ShipInventory = new List<Ship> { ship } };

            bool result = Battleships.Program.CheckForShipCollision(coordinates, player);

            // Should return as true 

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void Test_For_Duplicate_Ship_False()
        {

            List<Coordinates> coordinates = new() { new Coordinates { X = 3, Y = 7 }, new Coordinates { X = 4, Y = 7 }, new Coordinates { X = 5, Y = 7 }, new Coordinates { X = 6, Y = 8 }, new Coordinates { X = 7, Y = 7 } };


            Ship ship = new() { CoOrds = new() { new Coordinates { X = 4, Y = 2 }, new Coordinates { X = 4, Y = 3 }, new Coordinates { X = 4, Y = 4 }, new Coordinates { X = 4, Y = 5 }, new Coordinates { X = 4, Y = 6 } } };
            Player player = new() { ShipInventory = new List<Ship> { ship } };

            bool result = Battleships.Program.CheckForShipCollision(coordinates, player);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void Test_For_Player_Eliminated_True()
        {

            List<Ship> ship = new() { new Ship { IsShipEliminated = true }, new Ship { IsShipEliminated = true }, new Ship { IsShipEliminated = true } };
            Player player = new() { ShipInventory = ship};

            bool result = player.CheckIfPlayerIsEliminated(player);

            Assert.IsTrue(result);

        }

        [TestMethod]
        public void Test_For_Player_Eliminated_False()
        {
            List<Ship> ship = new() { new Ship { IsShipEliminated = true }, new Ship { IsShipEliminated = true }, new Ship { IsShipEliminated = false } };
            Player player = new() { ShipInventory = ship };

            bool result = player.CheckIfPlayerIsEliminated(player);
           
            Assert.IsFalse(result);

        }

        [TestMethod]
        public void Test_For_Ship_Eliminated_True()
        {
            List<Coordinates> coordinates = new() { new Coordinates { X = 3, Y = 7, WasCoordHit = true }, new Coordinates { X = 4, Y = 7, WasCoordHit = true }, new Coordinates { X = 5, Y = 7, WasCoordHit = true }, new Coordinates { X = 6, Y = 8, WasCoordHit = true }, new Coordinates { X = 7, Y = 7, WasCoordHit = true } };

            Ship ship = new() { CoOrds = coordinates, NumOfSpaces = 5 };

            bool result = ship.CheckIfShipIsEliminated(ship);

            Assert.IsTrue(result);

        }

        [TestMethod]
        public void Test_For_Ship_Eliminated_False()
        {
            List<Coordinates> coordinates = new() { new Coordinates { X = 3, Y = 7, WasCoordHit = true }, new Coordinates { X = 4, Y = 7, WasCoordHit = false }, new Coordinates { X = 5, Y = 7, WasCoordHit = true }, new Coordinates { X = 6, Y = 8, WasCoordHit = true }, new Coordinates { X = 7, Y = 7, WasCoordHit = true } };

            Ship ship = new() { CoOrds = coordinates, NumOfSpaces = 5 };

            bool result = ship.CheckIfShipIsEliminated(ship);

            Assert.IsFalse(result);

        }

        [TestMethod]
        public void Test_AddRandomShipsToGame()
        {
            Player player = new();

            for (int i = 0; i <= 4; i++)
            {
                player.ShipInventory.Add(new Ship { NumOfSpaces = 5});
            }

            Battleships.Program.AddRandomShipsToGame(player, player.ShipInventory);

            int numofcoordinates = player.ShipInventory[0].CoOrds.Count;

            // Each ship should contain an equal number of coordinates as spaces occupied

            for (int i = 0;i < player.ShipInventory.Count; i++)
            {
                Assert.IsTrue(numofcoordinates == player.ShipInventory[i].NumOfSpaces);
            }
        }

        [TestMethod]
        public void TestForCollidingCoordinates()
        {
            Player player = new();

            for (int i = 0; i <= 4; i++)
            {
                player.ShipInventory.Add(new Ship { NumOfSpaces = 5 });
            }

            int x = 2;
            int y = 3;

            for (int i = 0; i < player.ShipInventory.Count ; i++)
            {
                Battleships.Program.GenerateCoordinateRanges(x, y, player.ShipInventory[i], player);
            }

            for (int i = 0; i < player.ShipInventory.Count; i++)
            {
                List<Coordinates> coordsOfShipToCheck = player.ShipInventory[i].CoOrds;

                for (int j = 0; j < player.ShipInventory.Count; j++)
                {
                    for (int l = 0; l < player.ShipInventory[j].CoOrds.Count; l++)
                    {
                        for (int m = 0; m < coordsOfShipToCheck.Count; m++)
                        {
                            // fail if the coordinates to be checked match the coordinates in the ship inventory and ISN'T the same ship being checked in the loop
                            if (player.ShipInventory[j].CoOrds[l].X == coordsOfShipToCheck[m].X && player.ShipInventory[j].CoOrds[l].Y == coordsOfShipToCheck[m].Y && i != j)
                            {
                                Assert.Fail();
                            }
                        }

                    }
                }

            }

        }
    }
}